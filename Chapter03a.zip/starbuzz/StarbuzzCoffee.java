public class StarbuzzCoffee {
 
	public static void main(String args[]) {
		Beverage drinky = new HouseBlend();
		drinky = new Mocha(drinky);
		drinky = new Mocha(drinky);
		drinky = new Mocha(drinky);
		drinky = new Whip(drinky);
		drinky = new Soy(drinky);
		drinky = new Stevia(drinky);
		System.out.println(drinky.getDescription() 
				+ " $" + drinky.cost());
	}
}
