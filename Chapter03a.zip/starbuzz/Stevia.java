public class Stevia extends CondimentDecorator {
	public Stevia(Beverage beverage) {
		this.beverage = beverage;
	}
	
	public String getDescription() {
		return beverage.getDescription() + ", Stevia";
	}
	
	public double cost() {
		return 0 + beverage.cost();
	}
}